import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# import seaborn as sns
# sns.set()

# multi_0 = open("//home/v-homin/Digger_Guider/data/multi_l2_0.txt", "r")
# multi_00001 = open("//home/v-homin/Digger_Guider/data/multi_l2_0.0001.txt", "r")
# multi_0001 = open("//home/v-homin/Digger_Guider/data/multi_l2_0.001.txt", "r")
# multi_001 = open("//home/v-homin/Digger_Guider/data/multi_l2_0.01.txt", "r")
# multi_01 = open("//home/v-homin/Digger_Guider/data/multi_l2_0.1.txt", "r")
#
# train_0 = []
# valid_0 = []
# train_01 = []
# valid_01 = []
# train_001 = []
# valid_001 = []
# train_0001 = []
# valid_0001 = []
# train_00001 = []
# valid_00001 = []
#
# for line in multi_0:
#     train_0.append(float(line.strip().split(", ")[0].split(" ")[1]))
#     valid_0.append(float(line.strip().split(", ")[1].split(" ")[1]))
#
# for line in multi_01:
#     train_01.append(float(line.strip().split(", ")[0].split(" ")[1]))
#     valid_01.append(float(line.strip().split(", ")[1].split(" ")[1]))
#
# for line in multi_001:
#     train_001.append(float(line.strip().split(", ")[0].split(" ")[1]))
#     valid_001.append(float(line.strip().split(", ")[1].split(" ")[1]))
#
# for line in multi_0001:
#     train_0001.append(float(line.strip().split(", ")[0].split(" ")[1]))
#     valid_0001.append(float(line.strip().split(", ")[1].split(" ")[1]))
#
# for line in multi_00001:
#     train_00001.append(float(line.strip().split(", ")[0].split(" ")[1]))
#     valid_00001.append(float(line.strip().split(", ")[1].split(" ")[1]))
#
# train_0_df = pd.DataFrame({"epoch": range(len(train_0)), 'loss': train_0})
# valid_0_df = pd.DataFrame({"epoch": range(len(valid_0)), 'loss': valid_0})
# train_01_df = pd.DataFrame({"epoch": range(len(train_01)), 'loss': train_01})
# valid_01_df = pd.DataFrame({"epoch": range(len(valid_01)), 'loss': valid_01})
# train_001_df = pd.DataFrame({"epoch": range(len(train_001)), 'loss': train_001})
# valid_001_df = pd.DataFrame({"epoch": range(len(valid_001)), 'loss': valid_001})
# train_0001_df = pd.DataFrame({"epoch": range(len(train_0001)), 'loss': train_0001})
# valid_0001_df = pd.DataFrame({"epoch": range(len(valid_0001)), 'loss': valid_0001})
# train_00001_df = pd.DataFrame({"epoch": range(len(train_00001)), 'loss': train_00001})
# valid_00001_df = pd.DataFrame({"epoch": range(len(valid_00001)), 'loss': valid_00001})
# # fig = sns.relplot(x="epoch", y="loss", kind="line", data=train_0_df)
# # fig = sns.relplot(x="epoch", y="loss", kind="line", data=train_01_df)
# # fig = sns.relplot(x="epoch", y="loss", kind="line", data=train_001_df)
# # fig.savefig("output.png")
# fig, ax = plt.subplots()  # Create a figure and an axes.
# ax.plot(train_0_df["epoch"][:31], train_0_df["loss"][:31], label="l2_norm_0.0")
# ax.plot(train_01_df["epoch"][:31], train_01_df["loss"][:31], label="l2_norm_0.1")
# ax.plot(train_001_df["epoch"][:31], train_001_df["loss"][:31], label="l2_norm_0.01")
# ax.plot(train_0001_df["epoch"][:31], train_0001_df["loss"][:31], label="l2_norm_0.001")
# ax.plot(train_00001_df["epoch"][:31], train_00001_df["loss"][:31], label="l2_norm_0.0001")
# ax.legend()
# ax.set_xlabel('Epoches')
# ax.set_ylabel('Loss')
# # plt.xticks(np.arange(0,30,5))
# plt.yticks(np.arange(0,3,0.5))
#
# fig.savefig('foo.png')
#
# fig, ax = plt.subplots()  # Create a figure and an axes.
# ax.plot(valid_0_df["epoch"][:31], valid_0_df["loss"][:31], label="l2_norm_0.0")
# ax.plot(valid_01_df["epoch"][:31], valid_01_df["loss"][:31], label="l2_norm_0.1")
# ax.plot(valid_001_df["epoch"][:31], valid_001_df["loss"][:31], label="l2_norm_0.01")
# ax.plot(valid_0001_df["epoch"][:31], valid_0001_df["loss"][:31], label="l2_norm_0.001")
# ax.plot(valid_00001_df["epoch"][:31], valid_00001_df["loss"][:31], label="l2_norm_0.0001")
# ax.legend()
# ax.set_xlabel('Epoches')
# ax.set_ylabel('Loss')
# # plt.xticks(np.arange(0,30,5))
# plt.yticks(np.arange(1.5,2.7,0.2))
# fig.savefig('foo_valid.png')

# high_0 = open("//home/v-homin/Digger_Guider/data/1.5_l2_0.txt", "r")
# high_4 = open("//home/v-homin/Digger_Guider/data/1.5_l2_-4.txt", "r")
# high_5 = open("//home/v-homin/Digger_Guider/data/1.5_l2_-5.txt", "r")
# high_6 = open("//home/v-homin/Digger_Guider/data/1.5_l2_-6.txt", "r")
# # multi_01 = open("//home/v-homin/Digger_Guider/data/multi_l2_0.1.txt", "r")
#
# train_0 = []
# valid_0 = []
# train_4 = []
# valid_4 = []
# train_5 = []
# valid_5 = []
# train_6 = []
# valid_6 = []
#
# for line in high_0:
#     if "current step:" in line:
#         train_0.append(float(line.strip().split(", ")[0].split(" ")[-1]))
#         valid_0.append(float(line.strip().split(", ")[1].split(" ")[1][:-1]))
#
# for line in high_4:
#     if "current step:" in line:
#         train_4.append(float(line.strip().split(", ")[0].split(" ")[-1]))
#         valid_4.append(float(line.strip().split(", ")[1].split(" ")[1][:-1]))
#
# for line in high_5:
#     if "current step:" in line:
#         train_5.append(float(line.strip().split(", ")[0].split(" ")[-1]))
#         valid_5.append(float(line.strip().split(", ")[1].split(" ")[1][:-1]))
#
# for line in high_6:
#     if "current step:" in line:
#         train_6.append(float(line.strip().split(", ")[0].split(" ")[-1]))
#         valid_6.append(float(line.strip().split(", ")[1].split(" ")[1][:-1]))
#
# train_0_df = pd.DataFrame({"epoch": range(len(train_0)), 'loss': train_0})
# valid_0_df = pd.DataFrame({"epoch": range(len(valid_0)), 'loss': valid_0})
# train_4_df = pd.DataFrame({"epoch": range(len(train_4)), 'loss': train_4})
# valid_4_df = pd.DataFrame({"epoch": range(len(valid_4)), 'loss': valid_4})
# train_5_df = pd.DataFrame({"epoch": range(len(train_5)), 'loss': train_5})
# valid_5_df = pd.DataFrame({"epoch": range(len(valid_5)), 'loss': valid_5})
# train_6_df = pd.DataFrame({"epoch": range(len(train_6)), 'loss': train_6})
# valid_6_df = pd.DataFrame({"epoch": range(len(valid_6)), 'loss': valid_6})
#
# # fig = sns.relplot(x="epoch", y="loss", kind="line", data=train_0_df)
# # fig = sns.relplot(x="epoch", y="loss", kind="line", data=train_01_df)
# # fig = sns.relplot(x="epoch", y="loss", kind="line", data=train_001_df)
# # fig.savefig("output.png")
# fig, ax = plt.subplots()  # Create a figure and an axes.
# ax.plot(train_0_df["epoch"][:1000], train_0_df["loss"][:1000], label="l2_norm_0")
# ax.plot(train_4_df["epoch"][:1000], train_4_df["loss"][:1000], label="l2_norm_1e-4")
# ax.plot(train_5_df["epoch"][:1000], train_5_df["loss"][:1000], label="l2_norm_1e-5")
# ax.plot(train_6_df["epoch"][:1000], train_6_df["loss"][:1000], label="l2_norm_1e-6")
#
# ax.legend()
# ax.set_xlabel('Steps')
# ax.set_ylabel('Loss')
# # plt.xticks(np.arange(0,30,5))
# plt.yticks(np.arange(0,3,0.5))
#
# fig.savefig('1.5_train.png')
#
# fig, ax = plt.subplots()  # Create a figure and an axes.
# ax.plot(valid_0_df["epoch"][:1000], valid_0_df["loss"][:1000], label="l2_norm_0")
# ax.plot(valid_4_df["epoch"][:1000], valid_4_df["loss"][:1000], label="l2_norm_1e-4")
# ax.plot(valid_5_df["epoch"][:1000], valid_5_df["loss"][:1000], label="l2_norm_1e-5")
# ax.plot(valid_6_df["epoch"][:1000], valid_6_df["loss"][:1000], label="l2_norm_1e-6")
#
# ax.legend()
# ax.set_xlabel('Steps')
# ax.set_ylabel('Loss')
# # plt.xticks(np.arange(0,30,5))
# plt.yticks(np.arange(1,3,0.5))
# fig.savefig('1.5_valid.png')

high_0 = open("//home/v-homin/Digger_Guider/data/low_l2_0.txt", "r")
high_4 = open("//home/v-homin/Digger_Guider/data/low_l2_-4.txt", "r")
high_5 = open("//home/v-homin/Digger_Guider/data/low_l2_-5.txt", "r")
high_6 = open("//home/v-homin/Digger_Guider/data/low_l2_-6.txt", "r")
# multi_01 = open("//home/v-homin/Digger_Guider/data/multi_l2_0.1.txt", "r")

train_0 = []
valid_0 = []
train_4 = []
valid_4 = []
train_5 = []
valid_5 = []
train_6 = []
valid_6 = []

for line in high_0:
    if "current step:" in line:
        train_0.append(float(line.strip().split(", ")[0].split(" ")[-1]))
        valid_0.append(float(line.strip().split(", ")[1].split(" ")[1][:-1]))

for line in high_4:
    if "current step:" in line:
        train_4.append(float(line.strip().split(", ")[0].split(" ")[-1]))
        valid_4.append(float(line.strip().split(", ")[1].split(" ")[1][:-1]))

for line in high_5:
    if "current step:" in line:
        train_5.append(float(line.strip().split(", ")[0].split(" ")[-1]))
        valid_5.append(float(line.strip().split(", ")[1].split(" ")[1][:-1]))

for line in high_6:
    if "current step:" in line:
        train_6.append(float(line.strip().split(", ")[0].split(" ")[-1]))
        valid_6.append(float(line.strip().split(", ")[1].split(" ")[1][:-1]))

new_train_0 = []
new_train_4 = []
new_train_5 = []
new_train_6 = []
for i in range(250):
    new_train_0.append(np.median(train_0[4 * i:4 * i + 4]))
    new_train_4.append(np.median(train_4[4 * i:4 * i + 4]))
    new_train_5.append(np.median(train_5[4 * i:4 * i + 4]))
    new_train_6.append(np.median(train_6[4 * i:4 * i + 4]))


# for i in range(197):
#     if abs(new_train_0[i] - new_train_0[i+1]) > 0.02:
#         new_train_0[i + 1] = (new_train_0[i] + new_train_0[i+2] + new_train_0[i+3])/3
#     if abs(new_train_4[i] - new_train_4[i+1]) > 0.02:
#         new_train_4[i + 1] = (new_train_4[i] + new_train_4[i+2] + new_train_4[i+3])/3
#     if abs(new_train_5[i] - new_train_5[i+1]) > 0.02:
#         new_train_5[i + 1] = (new_train_5[i] + new_train_5[i+2] + new_train_5[i+3])/3
#     if abs(new_train_6[i] - new_train_6[i+1]) > 0.02:
#         new_train_6[i + 1] = (new_train_6[i] + new_train_6[i+2] + new_train_6[i+3])/3

train_0_df = pd.DataFrame({"epoch": range(0, len(train_0), 4), 'loss': new_train_0})
valid_0_df = pd.DataFrame({"epoch": range(len(valid_0)), 'loss': valid_0})
train_4_df = pd.DataFrame({"epoch": range(0, len(train_4), 4), 'loss': new_train_4})
valid_4_df = pd.DataFrame({"epoch": range(len(valid_4)), 'loss': valid_4})
train_5_df = pd.DataFrame({"epoch": range(0, len(train_5), 4), 'loss': new_train_5})
valid_5_df = pd.DataFrame({"epoch": range(len(valid_5)), 'loss': valid_5})
train_6_df = pd.DataFrame({"epoch": range(0, len(train_6), 4), 'loss': new_train_6})
valid_6_df = pd.DataFrame({"epoch": range(len(valid_6)), 'loss': valid_6})

# fig = sns.relplot(x="epoch", y="loss", kind="line", data=train_0_df)
# fig = sns.relplot(x="epoch", y="loss", kind="line", data=train_01_df)
# fig = sns.relplot(x="epoch", y="loss", kind="line", data=train_001_df)
# fig.savefig("output.png")
fig, ax = plt.subplots()  # Create a figure and an axes.
ax.plot(train_4_df["epoch"], train_4_df["loss"], label="train_l2norm_0.0", color="green")

ax.plot(train_5_df["epoch"], train_5_df["loss"], label="train_l2norm_0.01", color="cornflowerblue")    # orange cornflowerblue
# ax.plot(train_6_df["epoch"], train_6_df["loss"], label="train_l2_norm_0.001", color="cornflowerblue")
ax.plot(train_0_df["epoch"], train_0_df["loss"], label="train_l2norm_0.1", color="red")
# ax.legend()
# ax.set_xlabel('Steps')
# ax.set_ylabel('Loss')
# # plt.xticks(np.arange(0,30,5))
# plt.yticks(np.arange(0,3,0.5))
#
# fig.savefig('1.5_train.png')

# fig, ax = plt.subplots()  # Create a figure and an axes.
ax.plot(valid_4_df["epoch"], valid_4_df["loss"], label="valid_l2norm_0.1", color="lightgreen")
ax.plot(valid_5_df["epoch"], valid_5_df["loss"], label="valid_l2norm_0.01", color="steelblue")  # gold
# ax.plot(valid_6_df["epoch"], valid_6_df["loss"], label="valid_l2_norm_0.001", color="lightblue")
ax.plot(valid_0_df["epoch"], valid_0_df["loss"], label="valid_l2norm_0.0", color="coral")


ax.legend(ncol=2, prop={'weight':"semibold", 'size':12})
ax.set_xlabel('Iterations', fontsize=17, fontweight="semibold")
ax.set_ylabel('Loss', fontsize=17, fontweight="semibold")
# plt.xticks(np.arange(0,30,5))
# plt.legend(prop={'weight':"semibold"})

plt.xlim(0, 400)
plt.ylim(1.8, 2.4)

plt.tick_params(direction='in')
plt.yticks(np.arange(1.8,2.41,0.1), fontsize=15, fontweight="semibold")
plt.xticks(np.arange(0,401,100), fontsize=15, fontweight="semibold")

for axis in ['top','bottom','left','right']:
  ax.spines[axis].set_linewidth(2)

plt.grid(axis="y")
fig.savefig('1.png', dpi=300)