## Contrastive Multi-granularity Learning for Stock Trend Prediction

Code address:  v-homin@10.190.174.39:/home/v-homin/CMLF



1. ### Dependencies

   Install packages from `requirements.txt`.  

   * Note that the most convenient server to install `qlib` is  `msraml-incubation-019`  

   * qlib detailed tutorial: [tutorial](http://10.150.144.153:9000/tutorial.html)

     

2. ### **Load data using qlib**

   ```shell
   $ cd ./load_data
   ```

   #### **Download daily data**:

   ```shell
   $ python load_dataset.py
   ```

   * Change parameter `market` to get data from different dataset: `csi300`, `csi800`, `all` etc.

   #### Download high-frequency data:

   ```shell
   $ python high_freq_resample.py
   ```

   * Change parameter `N` to get data from different frequencies: `15min`, `30min`, `120min` etc.



3. ### **Run**

   ```shell
   $ cd ./framework
   ```

   #### Train `CMLF` model:
   
   * **Pre-training stage:**
   
     ```shell
     $ python main_contrast.py with config/contrast_all_2_encoder_new.json model_name=contrastiv_all_2_stage_new
     ```
   
   * **Fine-tuning stage:**
   
     ```shell
     $ python main_contrast_2_stage.py with config/contrast_all_2_stage_new.json model_name=contrastive_all_2_stage_new
     ```

   #### Train `baseline` models:

   ```shell
   $ python main.py with config/baseline.json model_name=rnn_v1
   ```

   * Add `hyper-param` = {values} after `with` or change them in `config/baseline.json`
   * List of model_name :
     * `itosfm`: SFM  (Zhang, Aggarwal, and Qi 2017) 
     * `alstm`: ALSTM (Qin et al. 2017)
     * `adv_alstm`: Adv-ALSTM (Feng et al. 2019)
     * Prediction results of each model are saved as `pred_{model_name}.pkl` in `./out/`.

   #### Run `Market Trading Simulation`:

   * Prerequisites:   
     * Server with qlib
     * Prediction results

   ```shell
   $ python trade_sim.py
   ```

   #### Records
    Records for each experiment are saved in `./framework/my_runs/`.  
    Each record file includes: 

    > config.json
    >
    > * contains the parameter settings and data path.
   
    > cout.txt
    >
    > * contains the name of dataset, detailed model output, and experiment results.
   
    > pred_{model_name}.pkl
    >
    > * contains the  `score` (model prediction) and `label`

	 >run.json
	 >
	 >* contains the hash ids of every script used in the experiment. And the source code can be found in `./framework/my_runs/source/`.
	
	**Note that the experiment records for _Contrastive Multi-granularity Learning for Stock Trend Prediction_ have been listed in `/my_runs/`**



4. ### **Config of CMLF**

   * **Pre-training stage:**

     > CSI300:  
     > > ```json
     > > {
     > > "seed": 2,
     > > "loader_name": "daily_loader_contrast",
     > > "output_path" : "/home/v-homin/Digger_Guider/framework/out/contrast",
     > > "comt" : "hft",
     > > "run_on" : false,
     > > "daily_loader_contrast": {
     > >   "dset": [
     > >       "day_csi300_till_20200104",
     > >       "hft_15m_csi300_till_20200104"
     > >   ],
     > >   "train_start_date": "2007-02-16",
     > >   "train_end_date": "2014-12-31",
     > >   "valid_start_date": "2015-01-01",
     > >   "valid_end_date": "2016-12-31",
     > >   "test_start_date": "2017-01-01",
     > >   "test_end_date": "2020-01-01",
     > >   "train_shuffle" : true,
     > >   "batch_size": 300,
     > >   "pre_n_day" : 20,
     > >   "DATA_PATH": "//home/v-homin/Digger_Guider/data",
     > >   "negative_sample": 5
     > > },
     > > "model_name": "contrastive_all_2_encoder_new",
     > > "contrastive_all_2_encoder_new": {
     > >   "input_shape": [
     > >       [6, 1, 20],
     > >       [6, 16, 20]
     > >   ],
     > >   "rnn_type": "GRU",
     > >   "verbose": 100,
     > >   "rnn_layer" : 2,
     > >   "dropout": 0,
     > >   "early_stopping_rounds":5,
     > >   "hid_size": 64,
     > >   "optim_args": {"lr":1e-3},
     > >   "negative_sample": 5,
     > >   "fusion": "add",
     > >   "contrast_ratio": {"point": 0.05, "trend": 1}
     > > }
     > > }   
     > > ```

     > CSI 800
     > > ```json
     > > {
     > > "seed": 2,
     > > "loader_name": "daily_loader_contrast",
     > > "output_path" : "/home/v-homin/Digger_Guider/framework/out/contrast",
     > > "comt" : "hft",
     > > "run_on" : false,
     > > "daily_loader_contrast": {
     > >   "dset": [
     > >       "day_csi800_till_20200104",
     > >       "hft_15m_csi800_till_20200104"
     > >   ],
     > >   "train_start_date": "2007-02-16",
     > >   "train_end_date": "2014-12-31",
     > >   "valid_start_date": "2015-01-01",
     > >   "valid_end_date": "2016-12-31",
     > >   "test_start_date": "2017-01-01",
     > >   "test_end_date": "2020-01-01",
     > >   "train_shuffle" : true,
     > >   "batch_size": 800,
     > >   "pre_n_day" : 20,
     > >   "DATA_PATH": "//home/v-homin/Digger_Guider/data",
     > >   "negative_sample": 5
     > > },
     > > "model_name": "contrastive_all_2_encoder_new",
     > > "contrastive_all_2_encoder_new": {
     > >   "input_shape": [
     > >       [6, 1, 20],
     > >       [6, 16, 20]
     > >   ],
     > >   "rnn_type": "GRU",
     > >   "verbose": 100,
     > >   "rnn_layer" : 2,
     > >   "dropout": 0,
     > >   "early_stopping_rounds":5,
     > >   "hid_size": 64,
     > >   "optim_args": {"lr":1e-3},
     > >   "negative_sample": 5,
     > >   "fusion": "concat",
     > >   "contrast_ratio": {"point": 0.01, "trend": 1}
     > > }
     > > }   
     > > ```

   * **Fine-tuning stage:**

     > CSI300:  
     > > ```json
     > > {
     > > "seed": 2,
     > > "loader_name": "daily_loader_contrast",
     > > "output_path" : "/home/v-homin/Digger_Guider/framework/out/contrast",
     > > "comt" : "hft",
     > > "run_on" : false,
     > > "daily_loader_contrast": {
     > >   "dset": [
     > >       "day_csi300_till_20200104",
     > >       "hft_15m_csi300_till_20200104"
     > >   ],
     > >   "train_start_date": "2007-02-16",
     > >   "train_end_date": "2014-12-31",
     > >   "valid_start_date": "2015-01-01",
     > >   "valid_end_date": "2016-12-31",
     > >   "test_start_date": "2017-01-01",
     > >   "test_end_date": "2020-01-01",
     > >   "train_shuffle" : true,
     > >   "batch_size": 300,
     > >   "pre_n_day" : 20,
     > >   "DATA_PATH": "//home/v-homin/Digger_Guider/data",
     > >   "negative_sample": 5
     > > },
     > > "model_name": "contrastive_all_2_stage_new",
     > > "contrastive_all_2_stage_new": {
     > >   "input_shape": [
     > >       [6, 1, 20],
     > >       [6, 16, 20]
     > >   ],
     > >   "rnn_type": "GRU",
     > >   "verbose": 100,
     > >   "rnn_layer" : 2,
     > >   "dropout": 0,
     > >   "early_stopping_rounds":5,
     > >   "hid_size": 64,
     > >   "optim_args": {"lr":1e-2},
     > >   "negative_sample": 5,
     > >   "pretrain_path": "//home/v-homin/Digger_Guider/framework/my_runs/169/model.bin",
     > >   "fusion": "add"
     > > }
     > > }   
     > > ```
   
     > CSI 800
     > > ```json
     > > {
     > >  "seed": 2,
     > >  "loader_name": "daily_loader_contrast",
     > >  "output_path" : "/home/v-homin/Digger_Guider/framework/out/contrast",
     > >  "comt" : "hft",
     > >  "run_on" : false,
     > >  "daily_loader_contrast": {
     > >      "dset": [
     > >          "day_csi800_till_20200104",
     > >          "hft_15m_csi800_till_20200104"
     > >      ],
     > >      "train_start_date": "2007-02-16",
     > >      "train_end_date": "2014-12-31",
     > >      "valid_start_date": "2015-01-01",
     > >      "valid_end_date": "2016-12-31",
     > >      "test_start_date": "2017-01-01",
     > >      "test_end_date": "2020-01-01",
     > >      "train_shuffle" : true,
     > >      "batch_size": 800,
     > >      "pre_n_day" : 20,
     > >      "DATA_PATH": "//home/v-homin/Digger_Guider/data",
     > >      "negative_sample": 5
     > >  },
     > >  "model_name": "contrastive_all_2_stage_new",
     > >  "contrastive_all_2_stage_new": {
     > >      "input_shape": [
     > >          [6, 1, 20],
     > >          [6, 16, 20]
     > >      ],
     > >   "rnn_type": "GRU",
     > >      "verbose": 100,
     > >      "rnn_layer" : 2,
     > >      "dropout": 0,
     > >      "early_stopping_rounds":5,
     > >      "hid_size": 64,
     > >      "optim_args": {"lr":1e-2},
     > >      "negative_sample": 5,
     > >      "pretrain_path": "//home/v-homin/Digger_Guider/framework/my_runs/251/model.bin",
     > >      "fusion": "concat"
     > >  }
     > > }   
     > > ```



5. ### Hack

   - `common` : add your functions here
   - `models` : add your model here
   - `loaders`: add your data loader here
   - `config` : put your config file here