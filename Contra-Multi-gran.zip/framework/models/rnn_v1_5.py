import copy
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

from common.utils import pprint, AverageMeter
from common.functions import get_loss_fn, get_metric_fn

from sacred import Ingredient

model_ingredient = Ingredient('rnn_v1_5')


@model_ingredient.config
def model_config():
    # architecture
    input_shape = [6, 60]
    rnn_type = 'LSTM'  # LSTM/GRU
    rnn_layer = 2
    hid_size = 64
    dropout = 0
    # optimization
    optim_method = 'Adam'
    optim_args = {'lr': 1e-3}
    loss_fn = 'mse'
    eval_metric = 'corr'
    verbose = 500
    max_steps = 50
    early_stopping_rounds = 5


class Model(nn.Module):
    @model_ingredient.capture
    def __init__(self,
                 input_shape,
                 rnn_type='LSTM',
                 rnn_layer=2,
                 hid_size=64,
                 dropout=0,
                 optim_method='Adam',
                 optim_args={'lr': 1e-3},
                 loss_fn='mse',
                 eval_metric='corr'):

        super().__init__()

        # Architecture
        self.hid_size = hid_size
        self.input_size = input_shape[0]
        self.input_length = input_shape[1]
        self.input_day = input_shape[2]
        self.dropout = dropout
        self.rnn_layer = rnn_layer
        self.rnn_type = rnn_type

        self._build_model()

        # Optimization
        self.optimizer = getattr(optim, optim_method)(self.parameters(),
                                                      **optim_args)
        self.loss_fn = get_loss_fn(loss_fn)
        self.metric_fn = get_metric_fn(eval_metric)

        if torch.cuda.is_available():
            self.cuda()

    def _build_model(self):

        try:
            klass = getattr(nn, self.rnn_type.upper())
        except:
            raise ValueError('unknown rnn_type `%s`' % self.rnn_type)
        self.net = nn.Sequential()
        self.net.add_module('fc_in',nn.Linear(in_features=self.input_size, out_features=self.hid_size))
        self.net.add_module('act',nn.Tanh())
        self.rnn = klass(input_size=self.hid_size,
                         hidden_size=self.hid_size,
                         num_layers=self.rnn_layer,
                         batch_first=True,
                         dropout=self.dropout)

        self.fc_out = nn.Linear(in_features=self.hid_size, out_features=1)

    def forward(self, inputs):
        inputs = inputs.view(-1, self.input_day, self.input_size, self.input_length)
        inputs = inputs.permute(0, 1, 3, 2) #[bathc, input_day, input_size, input_len] -> [bathc, input_day, input_len, input_size]
        inputs = inputs.reshape(-1, self.input_day * self.input_length, self.input_size)
        out, _ = self.rnn(self.net(inputs))
        # pprint(f'out.shape : {out.shape}')
        # output_shape : [batch, seq_len, num_directions * hidden_size ]
        # hidden_shape : [batch, num_layers * num_directions, hidden_size]
        out = self.fc_out(out[:, -1, :]) # [batch, seq_len, num_directions * hidden_size] -> [batch, 1]
        return out[..., 0]

    @model_ingredient.capture
    # def fit(self,
    #         train_set,
    #         valid_set,
    #         run=None,
    #         max_steps=100,
    #         early_stopping_rounds=10,
    #         verbose=100):
    #
    #     best_score = np.inf
    #     stop_steps = 0
    #     best_params = copy.deepcopy(self.state_dict())
    #
    #     for step in range(max_steps):
    #         pprint('Step:', step)
    #         if stop_steps >= early_stopping_rounds:
    #             if verbose:
    #                 pprint('\tearly stop')
    #             break
    #         stop_steps += 1
    #         # training
    #         self.train()
    #         train_loss = AverageMeter()
    #         train_eval = AverageMeter()
    #         for i, (data, label) in enumerate(train_set):
    #             data = torch.tensor(data, dtype=torch.float)
    #             label = torch.tensor(label, dtype=torch.float)
    #             if torch.cuda.is_available():
    #                 data, label = data.cuda(), label.cuda()
    #             pred = self(data)
    #             loss = self.loss_fn(pred, label)
    #             self.optimizer.zero_grad()
    #             loss.backward()
    #             self.optimizer.step()
    #             train_loss.update(loss.item(), len(data))
    #             train_eval.update(self.metric_fn(pred, label).item())
    #             if verbose and i % verbose == 0:
    #                 # pprint('iter %s: train_loss %.6f, train_eval %.6f' %
    #                 #        (i, train_loss.avg, train_eval.avg))
    #                 pprint('iter' + str(i))
    #                 self.eval()
    #                 valid_loss = AverageMeter()
    #                 valid_eval = AverageMeter()
    #                 for j, (data_v, label_v) in enumerate(valid_set):
    #                     data_v = torch.tensor(data_v, dtype=torch.float)
    #                     label_v = torch.tensor(label_v, dtype=torch.float)
    #                     if torch.cuda.is_available():
    #                         data_v, label_v = data_v.cuda(), label_v.cuda()
    #                     with torch.no_grad():
    #                         pred_v = self(data_v)
    #                     loss_v = self.loss_fn(pred_v, label_v)
    #                     valid_loss.update(loss_v.item(), len(data_v))
    #                     valid_eval.update(self.metric_fn(pred_v, label_v).item())
    #                 # if run is not None:
    #                 #     run.add_scalar('Train/Loss', train_loss.avg, step)
    #                 #     run.add_scalar('Train/Eval', train_eval.avg, step)
    #                 #     run.add_scalar('Valid/Loss', valid_loss.avg, step)
    #                 #     run.add_scalar('Valid/Eval', valid_eval.avg, step)
    #                 if verbose:
    #                     pprint("current step: train_loss {:.6f}, valid_loss {:.6f}, ".format(
    #                         train_loss.avg, valid_loss.avg))
    #                 self.train()
    #
    #         # evaluation
    #         self.eval()
    #         valid_loss = AverageMeter()
    #         valid_eval = AverageMeter()
    #         for i, (data, label) in enumerate(valid_set):
    #             data = torch.tensor(data, dtype=torch.float)
    #             label = torch.tensor(label, dtype=torch.float)
    #             if torch.cuda.is_available():
    #                 data, label = data.cuda(), label.cuda()
    #             with torch.no_grad():
    #                 pred = self(data)
    #             loss = self.loss_fn(pred, label)
    #             valid_loss.update(loss.item(), len(data))
    #             valid_eval.update(self.metric_fn(pred, label).item())
    #         if run is not None:
    #             run.add_scalar('Train/Loss', train_loss.avg, step)
    #             run.add_scalar('Train/Eval', train_eval.avg, step)
    #             run.add_scalar('Valid/Loss', valid_loss.avg, step)
    #             run.add_scalar('Valid/Eval', valid_eval.avg, step)
    #         # if verbose:
    #         #     pprint("current step: train_loss {:.6f}, valid_loss {:.6f}, "
    #         #            "train_eval {:.6f}, valid_eval {:.6f}".format(
    #         #                train_loss.avg, valid_loss.avg, train_eval.avg,
    #         #                valid_eval.avg))
    #         if valid_eval.avg < best_score:
    #             # if verbose:
    #             #     pprint(
    #             #         '\tvalid update from {:.6f} to {:.6f}, save checkpoint.'
    #             #         .format(best_score, valid_eval.avg))
    #             best_score = valid_eval.avg
    #             stop_steps = 0
    #             best_params = copy.deepcopy(self.state_dict())
    #     # restore
    #     self.load_state_dict(best_params)
    def fit(self,
            train_set,
            valid_set,
            run=None,
            max_steps=100,
            early_stopping_rounds=10,
            verbose=100):
        best_score = np.inf
        stop_steps = 0
        best_params = copy.deepcopy(self.state_dict())

        for step in range(max_steps):

            pprint('Step:', step)
            if stop_steps >= early_stopping_rounds:
                if verbose:
                    pprint('\tearly stop')
                break
            stop_steps += 1
            # training
            self.train()
            train_loss = AverageMeter()
            train_eval = AverageMeter()
            for i, (data, label) in enumerate(train_set):
                data = torch.tensor(data, dtype=torch.float)
                label = torch.tensor(label, dtype=torch.float)
                if torch.cuda.is_available():
                    data, label = data.cuda(), label.cuda()
                pred = self(data)

                loss = self.loss_fn(pred, label)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                loss_ = loss.item()
                eval_ = self.metric_fn(pred, label).item()
                train_loss.update(loss_, len(data))
                train_eval.update(eval_)

                if verbose and i % verbose == 0:
                    pprint('iter %s: train_loss %.6f, train_eval %.6f' %
                           (i, train_loss.avg, train_eval.avg))
            # evaluation
            self.eval()
            valid_loss = AverageMeter()
            valid_eval = AverageMeter()
            for i, (data, label) in enumerate(valid_set):
                data = torch.tensor(data, dtype=torch.float)
                label = torch.tensor(label, dtype=torch.float)
                if torch.cuda.is_available():
                    data, label = data.cuda(), label.cuda()
                with torch.no_grad():
                    pred = self(data)
                loss = self.loss_fn(pred, label)
                valid_loss_ = loss.item()
                valid_eval_ = self.metric_fn(pred, label).item()
                valid_loss.update(valid_loss_, len(data))
                valid_eval.update(valid_eval_)

            if run is not None:
                run.add_scalar('Train/Loss', train_loss.avg, step)
                run.add_scalar('Train/Eval', train_eval.avg, step)
                run.add_scalar('Valid/Loss', valid_loss.avg, step)
                run.add_scalar('Valid/Eval', valid_eval.avg, step)
            if verbose:
                pprint("current step: train_loss {:.6f}, valid_loss {:.6f}, "
                       "train_eval {:.6f}, valid_eval {:.6f}".format(
                    train_loss.avg, valid_loss.avg, train_eval.avg,
                    valid_eval.avg))
            if valid_eval.avg < best_score:
                if verbose:
                    pprint(
                        '\tvalid update from {:.6f} to {:.6f}, save checkpoint.'
                            .format(best_score, valid_eval.avg))
                best_score = valid_eval.avg
                stop_steps = 0
                best_params = copy.deepcopy(self.state_dict())
        # restore
        self.load_state_dict(best_params)


    def predict(self, test_set):
        self.eval()
        preds = []
        for i, (data, _) in enumerate(test_set):
            data = torch.tensor(data, dtype=torch.float)
            if torch.cuda.is_available():
                data = data.cuda()
            with torch.no_grad():
                preds.append(self(data).cpu().numpy())
        return np.concatenate(preds)

    def save(self, model_path):
        torch.save(self.state_dict(), model_path)

    def load(self, model_path, strict=True):
        self.load_state_dict(torch.load(model_path), strict=strict)
