import pandas as pd
import numpy as np

# ori_label_csi300 = pd.read_pickle('/home/amax/data/day_csi300_ly.pkl')['LABEL0']
# ori_label_csi300 = pd.read_pickle('/home/amax/data/day_csi300_ly.pkl')['LABEL0']
# ori_label_csi300 = pd.read_pickle('/home/v-homin/Digger_Guider/data')['LABEL0']
ori_label_csi300 = pd.read_pickle('/home/amax/data/day_csi300_till_20200104.pkl')['LABEL0']
ori_label_nas = pd.read_pickle('/home/amax/data/day_ly_NASDAQ100_v3.pkl')['LABEL0_T+2']
ori_label_csi800 = pd.read_pickle('/home/amax/data/day_csi800_ly_v3_1.pkl')['LABEL0']
# ori_label_csi800 = pd.read_pickle('/home/amax/data/hft_15m_csi800_till_20200104.pkl')['LABEL0']
csi300 = pd.read_pickle('/home/amax/data/day_csi300_till_20200104.pkl')
#################
# DailyRNN_csi300 = pd.read_pickle('/home/amax/Digger_Guider/framework/my_runs/Daily_RNN_csi300/pred_rnn_v1_2.pkl')
# Coarse_csi300 = pd.read_pickle('/home/amax/Digger_Guider/framework/my_runs/Coarse_grained_Model_csi300/pred_cnn_v2_2.pkl')
# Fine_csi300 = pd.read_pickle('/home/amax/Digger_Guider/framework/my_runs/Fine_grained_Model_csi300/pred_rnn_v2_2.pkl')
# SFM_csi300 = pd.read_pickle('/home/amax/Digger_Guider/framework/my_runs/SFM_csi300/pred_rnn_v1_2.pkl')
# Ensemble_csi300 = pd.read_pickle('/home/amax/Digger_Guider/framework/out/pred_ensemble_v1_csi300.pkl')
# Digger_Guider_csi300 = pd.read_pickle('/home/amax/Digger_Guider/framework/my_runs/Digger_Guider_csi300/pred_cnn_rnn_v2.pkl')
# #################
# DailyRNN_csi800 = pd.read_pickle('/home/amax/Digger_Guider/framework/my_runs/Daily_RNN_csi800/pred_rnn_v1_2.pkl')
# Coarse_csi800 = pd.read_pickle('/home/amax/Digger_Guider/framework/my_runs/Coarse_grained_Model_csi800/pred_cnn_v2_2.pkl')
# Fine_csi800 = pd.read_pickle('/home/amax/Digger_Guider/framework/my_runs/Fine_grained_Model_csi800/pred_rnn_v2_2.pkl')
# SFM_csi800 = pd.read_pickle('/home/amax/Digger_Guider/framework/my_runs/SFM_csi800/pred_rnn_v1_2.pkl')
# Ensemble_csi800 = pd.read_pickle('/home/amax/Digger_Guider/framework/out/pred_ensemble_v1_csi800.pkl')
# Digger_Guider_csi800 = pd.read_pickle('/home/amax/Digger_Guider/framework/my_runs/60/pred_cnn_rnn_v2_0.pkl')
#################
rnn_v1_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_rnn_v1.pkl")
rnn_v2_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_rnn_v2.pkl")
rnn_multi_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_rnn_multi.pkl")
sfm_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_sfm.pkl")
alstm_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_alstm.pkl")
adv_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_adv.pkl")
contrastive_point_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_contrastive_point.pkl")
contrastive_trend_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_contrastive_trend.pkl")
contrastive_all_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_contrastive_all.pkl")
contrastive_gate_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_contrastive_gate.pkl")
alstm_300_new = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_alstm_48.pkl")
adv_300_new = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_adv_alstm_48.pkl")

##################
rnn_v1_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim_800/pred_rnn_v1.pkl")
rnn_v2_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim_800/pred_rnn_v2.pkl")
rnn_multi_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim_800/pred_rnn_multi.pkl")
sfm_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim_800/pred_sfm.pkl")
alstm_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim_800/pred_alstm.pkl")
adv_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim_800/pred_adv.pkl")
contrastive_point_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim_800/pred_contrastive_point.pkl")
contrastive_trend_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim_800/pred_contrastive_trend.pkl")
contrastive_all_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim_800/pred_contrastive_all.pkl")
# contrastive_gate_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/trade_sim/pred_contrastive_gate.pkl")

alstm_800_yang = pd.read_pickle("/home/v-homin/Digger_Guider/framework/my_runs/501/pred_alstm_4.pkl")
adv_800_yang = pd.read_pickle("/home/v-homin/Digger_Guider/framework/my_runs/499/pred_adv_alstm_4.pkl")

alstm_300_yang = pd.read_pickle("/home/v-homin/Digger_Guider/framework/my_runs/505/pred_alstm_6.pkl")
adv_300_yang = pd.read_pickle("/home/v-homin/Digger_Guider/framework/my_runs/524/pred_adv_alstm_24.pkl")

alstm_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/my_runs/538/pred_alstm_11.pkl")
adv_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/my_runs/542/pred_adv_alstm_24.pkl")

new_contrastive_point_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/my_runs/238/pred_contrastive_all_2.pkl")

cmlf_wo_ct_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/my_runs/600/pred_contrastive_all_2_stage_2.pkl")
cmlf_wo_cg_300 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/my_runs/601/pred_contrastive_all_2_stage_2.pkl")
cmlf_wo_ct_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/my_runs/594/pred_contrastive_all_2_stage_2.pkl")
cmlf_wo_cg_800 = pd.read_pickle("/home/v-homin/Digger_Guider/framework/my_runs/595/pred_contrastive_all_2_stage_2.pkl")


def mape(pred, actual):
    actual, pred = np.array(actual), np.array(pred)
    return np.mean(np.abs(actual - pred) / np.abs(actual + 1e-12)) * 100


def robust_zscore(x, axis=0):
    med = np.median(x, axis=axis)
    mad = np.median(np.abs(x - med), axis=axis)
    x = (x - med) / (mad * 1.4826 + 1e-12)
    return np.clip(x, -3, 3)


def inverse_robust_zscore(x, axis=0):
    med = np.median(x, axis=axis)
    mad = np.median(np.abs(x - med), axis=axis)
    x = x * (mad * 1.4826 + 1e-12) + med
    return x


def modified_rmse_v2(pred, label, dim=0):
    pred = zscore(pred)  # zscore before mse
    return np.sqrt(np.mean((pred - label) ** 2, axis=dim))


def zscore(x, axis=0):
    mean = np.mean(x, axis=axis)
    std = np.std(x, axis=axis)
    return (x - mean) / (std + 1e-12)


def inverse_zscore(x, axis=0):
    mean = np.mean(x, axis=axis)
    std = np.std(x, axis=axis)
    return x * (std + 1e-12) + mean


def modified_mae(pred, label):
    loss = np.abs(pred - label)
    loss = loss * K.abs(label)
    return np.mean(loss, keepdims=False)


def rmse(pred, label):
    return np.sqrt(np.mean((pred - label) ** 2))


def mae(pred, label):
    return np.mean(np.abs(pred - label))


def r2(pred, label):
    """calculate r-squared value

    NOTE:
    - this implementation assumes E[label] = 0
    """
    # label = zscore(label)
    # pred = zscore(pred)
    return 1 - np.mean((pred - label) ** 2) / np.var(label)


def group_func(sr, func, label_type):
    if label_type == 'ori':
        if func == 'rank_ic':
            return sr.groupby(level='datetime').apply(lambda x: x.score.corr(x.ori_label, method='spearman'))
        elif func == 'rmse':
            return sr.groupby(level='instrument').apply(lambda x: rmse(x.score.values, x.ori_label.values))
        elif func == 'mae':
            return sr.groupby(level='instrument').apply(lambda x: mae(x.score.values, x.ori_label.values))
        elif func == 'mape':
            return sr.groupby(level='instrument').apply(lambda x: mape(x.score.values, x.ori_label.values))
        elif func == 'r2':
            return sr.groupby(level='instrument').apply(lambda x: r2(x.score.values, x.ori_label.values))
        else:
            raise ValueError("ValueError exception thrown")

    elif label_type == 'z':
        if func == 'rank_ic':
            return sr.groupby(level='datetime').apply(lambda x: x.score.corr(x.label, method='spearman'))
        elif func == 'rmse':
            return sr.groupby(level='instrument').apply(lambda x: rmse(x.score.values, x.label.values))
        elif func == 'mae':
            return sr.groupby(level='instrument').apply(lambda x: mae(x.score.values, x.label.values))
        elif func == 'mape':
            return sr.groupby(level='instrument').apply(lambda x: mape(x.score.values, x.label.values))
        elif func == 'r2':
            return sr.groupby(level='instrument').apply(lambda x: r2(x.score.values, x.label.values))
        else:
            raise ValueError("ValueError exception thrown")
    else:
        raise ValueError("Wrong type")


def eval(sr, title, label_type):
    if title == 'csi300':
        sr['ori_label'] = ori_label_csi300.reindex(sr.index)
    elif title == 'csi800':
        sr['ori_label'] = ori_label_csi800.reindex(sr.index)
    # elif title == 'all':
    #     sr['ori_label'] = ori_label_all.reindex(sr.index)
    sr = sr.dropna()
    for func in ['rank_ic', 'rmse', 'mae', 'mape','r2']:
        a = group_func(sr,func,label_type)
        if func == 'rank_ic':
            print(func, a.mean(), a.mean() / a.std())
        else:
            print(func, a.mean())


# for res in [rnn_v1_300, rnn_v2_300, rnn_multi_300, sfm_300, alstm_300, adv_300, contrastive_point_300, contrastive_trend_300, contrastive_all_300, contrastive_gate_300]:
#     res.score = res.score * res.score.std() + res.score.mean()
#     eval(res,'csi300','ori')
#     print('#################')
#     del res

# for res in [rnn_v1_800, rnn_v2_800, rnn_multi_800, sfm_800, alstm_800, adv_800, contrastive_point_800, contrastive_trend_800, contrastive_all_800]:
#     res.score = res.score * ori_label_csi300.std() + ori_label_csi300.mean()
#     eval(res,'csi800','ori')
#     print('#################')
#     del res

# for res in [alstm_800_yang, adv_800_yang]:
#     # res.score = res.score * res.score.std() + res.score.mean()
#     res.score = res.score * ori_label_csi800.std() + ori_label_csi800.mean()
#     eval(res,'csi800','ori')
#     print('#################')
#     del res
#
# for res in [alstm_300_yang, adv_300_yang]:
#     # res.score = res.score * res.score.std() + res.score.mean()
#     res.score = res.score * ori_label_csi300.std() + ori_label_csi300.mean()
#     eval(res,'csi300','ori')
#     print('#################')
#     del res

# for res in [new_contrastive_point_800]:
#     res.score = res.score * res.score.std() + res.score.mean()
#     eval(res,'csi800','ori')
#     print('#################')
#     del res

for res in [cmlf_wo_ct_300, cmlf_wo_cg_300]:
    res.score = res.score * res.score.std() + res.score.mean()
    eval(res,'csi300','ori')
    print('#################')
    del res

for res in [cmlf_wo_ct_800, cmlf_wo_cg_800]:
    res.score = res.score * res.score.std() + res.score.mean()
    eval(res,'csi800','ori')
    print('#################')
    del res