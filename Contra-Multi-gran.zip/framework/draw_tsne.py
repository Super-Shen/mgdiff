import pandas as pd
import numpy as np

import random
from time import time
import matplotlib.pyplot as plt

from sklearn import datasets
from sklearn.manifold import TSNE

import pickle
import tqdm

def norm_embedding(data):
    x_min, x_max = np.min(data, 0), np.max(data, 0)
    data = (data - x_min) / (x_max - x_min)
    return data

def run_tsne(label, embedding, count, model):
    tsne = TSNE(n_components=2, init='pca')
    # final_embedding = []
    # final_label = []
    # for i in range(len(label)):
    #     if label[i] != 1:
    #         final_embedding.append(embedding[i])
    #         final_label.append(label[i])
    result = tsne.fit_transform(embedding)
    aim_data = norm_embedding(result)

    type1_x = []
    type1_y = []
    type2_x = []
    type2_y = []
    type3_x = []
    type3_y = []

    for i in range(len(label)):
        if label[i] == 0:
            type1_x.append(aim_data[i][0])
            type1_y.append(aim_data[i][1])
        if label[i] == 2:
            type3_x.append(aim_data[i][0])
            type3_y.append(aim_data[i][1])

    fig = plt.figure()
    ax = fig.add_subplot(111)
    # type1 = ax.scatter(type1_x, type1_y, s=20, c='mediumpurple')
    # type2 = ax.scatter(type2_x, type2_y, s=20, c='tomato')
    # type3 = ax.scatter(type3_x, type3_y, s=20, c="lightseagreen")
    # ax.legend((type1, type2, type3), ("0", "1", "2"), loc=0)
    type1 = ax.scatter(type1_x, type1_y, s=20, c='tomato')
    # type2 = ax.scatter(type2_x, type2_y, s=20, c='tomato')
    type3 = ax.scatter(type3_x, type3_y, s=20, c="lightseagreen")
    ax.legend((type1, type3), ("Bottom 20%", "Top 20%"), prop={'size':15})
    # plt.xlim(0.0, 1.0)
    # plt.ylim(0.0, 1.0)
    plt.yticks(fontsize=15)
    plt.xticks(fontsize=15)

    # plt.title("T-SNE")
    plt.savefig("tsne_3/{}_{}.eps".format(count, model), dpi=600)

ori_label_csi300 = pd.read_pickle('/home/amax/data/day_csi300_till_20200104.pkl')
baseline_embedding = pickle.load(open('96_embedding.pkl', 'rb'))
our_embedding = pickle.load(open('169_embedding.pkl', 'rb'))
test_set = pd.read_pickle('test_set.pkl')

# ori_label_csi300 = ori_label_csi300.reindex(test_set.index)
ori_label_csi300["counter"] = range(len(ori_label_csi300['LABEL0'].to_numpy()))

date_box = []

# # top10 = ori_label_csi300.groupby(by="datetime").apply(lambda x:x.nlargest(30, columns='label'))
# for date in ori_label_csi300.index.get_level_values('datetime').unique():
#     _df = ori_label_csi300.xs(date, level='datetime')
#
#     arr = _df['LABEL0'].to_numpy()
#     top_line_pos = arr.argsort()[-60:][::-1][-1]
#     bottom_line_pos = arr.argsort()[:60][::-1][0]
#     _df['LABEL0'] = _df['LABEL0'].map(lambda x: 0 if x <= _df['LABEL0'].iloc[bottom_line_pos] else 2 if x >= _df['LABEL0'].iloc[top_line_pos] else 1)
#     _df['datetime'] = date
#     date_box.append(_df)
#
# new_label = pd.concat(date_box).reset_index()
# new_label = new_label.set_index(['datetime', 'instrument']).sort_index(level='datetime')
# new_label=new_label.reindex(test_set.index)
#
# count = 0
# for date in ori_label_csi300.index.get_level_values('datetime').unique():
#     _df = new_label.xs(date, level='datetime')
#     label = _df['LABEL0'].to_numpy()
#     embedding_o = our_embedding[_df['counter'].to_numpy()]
#     embedding_b = baseline_embedding[_df['counter'].to_numpy()]
#     run_tsne(label, embedding_o, count, "our")
#     run_tsne(label, embedding_b, count, "base")
#     count += 1
#     if count == 100:
#         exit()


# ori_label_csi300 = ori_label_csi300.set_index(['datetime', 'instrument']).sort_index(level='instrument')
count = 0

for ins in ori_label_csi300.index.get_level_values('instrument').unique():
    count += 1
print (count)

count=0
ori_label_csi800 = pd.read_pickle('/home/v-homin/Digger_Guider/data/day_csi800_till_20200104.pkl')
for ins in ori_label_csi800.index.get_level_values('instrument').unique():
    count += 1
print (count)