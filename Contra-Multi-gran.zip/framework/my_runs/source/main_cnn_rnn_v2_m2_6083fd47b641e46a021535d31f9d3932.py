# -*- coding: utf-8 -*-
import os
import numpy as np
import pandas as pd
import pickle
try:
    from tensorboardX import SummaryWriter
    is_tensorboard_available = True
except Exception:
    is_tensorboard_available = False

import loaders as loaders_module
import models as models_module

from common.utils import (pprint, set_random_seed, create_output_path,
                          robust_zscore, count_num_params)
from common.functions import K  # BUG: sacred cannot save source files used in ingredients

from sacred import Experiment
from sacred.observers import FileStorageObserver

ex = Experiment('hft_pred',
                ingredients=[
                    loaders_module.daily_loader_v3.data_ingredient,
                    models_module.cnn_rnn_v2.model_ingredient
                ])

create_output_path('my_runs')
ex.observers.append(
    FileStorageObserver("my_runs", "my_runs/resource", "my_runs/source",
                        "my_runs/templete"))


def inference(dset, model, day_rep=None, pred_path=None):
    pred = pd.DataFrame(index=dset.index)
    pred['label'] = dset.label
    if day_rep is not None:
        pred['score'], tune_rep = model.predict(dset, day_rep)
    else:
        pred['score'], tune_rep = model.predict(dset)
    if pred_path is not None:
        pred.to_pickle(pred_path)
        ex.add_artifact(pred_path)
    robust_ic = pred.groupby(level='datetime').apply(
        lambda x: robust_zscore(x.label).corr(robust_zscore(x.score)))
    rank_ic = pred.groupby(level='datetime').apply(
        lambda x: x.label.corr(x.score, method='spearman'))
    pprint('Robust IC:', robust_ic.mean(), ',',
           robust_ic.mean() / robust_ic.std())
    pprint('Rank IC:', rank_ic.mean(), ',', rank_ic.mean() / rank_ic.std())
    return rank_ic.mean(), tune_rep

def Day_model_2(_run,
                output_path,
                day_model_2,
                day_train_set,
                day_valid_set,
                day_test_set,
                train_day_reps,
                valid_day_reps,
                test_day_reps,
                pred_path
                ):
    pprint('training day_model_2')
    tune_train_reps, tune_valid_reps = day_model_2.fit(day_train_set,
                                                       day_valid_set,
                                                       train_day_reps,
                                                       valid_day_reps,
                                                       run=_run)

    pprint('inference...')
    pprint('validation set day_model_2:')
    inference(dset=day_valid_set,
              model=day_model_2,
              day_rep=valid_day_reps,
              pred_path=pred_path)

    pprint('testing set day_model_2:')
    rank_ic_mean, tune_test_reps = inference(dset=day_test_set,
                             model=day_model_2,
                             day_rep=test_day_reps,
                             pred_path=pred_path)
    return rank_ic_mean, tune_train_reps, tune_valid_reps, tune_test_reps


@ex.config
def run_config():
    seed = 2
    output_path = '/home/amax/Documents/HM_CNN_RNN/out'
    loader_name = 'daily_loader_v3'
    model_name = 'rnn_v3'
    comt = 'rnn_60_1.0'
    run_on = False
    dsets = ["day_csi800_ly_v3_1", "hft_10m_csi800_ly_v3_1"]


@ex.main
def main(_run, seed, loader_name, model_name, output_path, comt, run_on,
         dsets):
    # path
    output_path = create_output_path(output_path)

    pprint('output path:', output_path)
    model_path = output_path + '/model.bin'
    pred_path = output_path+'/pred_%s_%d.pkl' %(model_name,seed)
    pprint('create loader `%s` and model `%s`...' % (loader_name, model_name))

    ###### Daily Model and Data Prepare #########
    set_random_seed(seed)
    day_loader = getattr(loaders_module, loader_name).DataLoader(dset=dsets[0])
    # day_model_1 = getattr(models_module, model_name).Day_Model_1()
    pprint('load daily data...')
    day_train_set, day_valid_set, day_test_set = day_loader.load_data()

    step = 2
    with open(output_path + '/train_day_reps_min_%d_saved.pkl' % step, 'rb') as file:
        min_train_day_reps = pickle.load(file)
        file.close()
    with open(output_path + '/valid_day_reps_min_%d_saved.pkl' % step, 'rb') as file:
        min_valid_day_reps = pickle.load(file)
        file.close()
    with open(output_path + '/test_day_reps_min_%d_saved.pkl' % step, 'rb') as file:
        min_test_day_reps = pickle.load(file)
        file.close()

    #######Day Model 2######
    set_random_seed(seed)
    _run = SummaryWriter(comment='_day_model2_min_%d'%step) if run_on else None
    day_model_2_rnn = getattr(models_module, model_name).Day_Model_2()
    rank_ic_mean_min, tune_train_reps, tune_valid_reps, tune_test_reps = Day_model_2(
        _run,
        output_path,
        day_model_2_rnn,
        day_train_set,
        day_valid_set,
        day_test_set,
        min_train_day_reps, 
        min_valid_day_reps, 
        min_test_day_reps,
        pred_path = pred_path
        )

if __name__ == '__main__':

    ex.run_commandline()
