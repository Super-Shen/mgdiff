import copy
import numpy as np
import pickle
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

from common.utils import pprint, AverageMeter
from common.functions import get_loss_fn, get_metric_fn

from sacred import Ingredient

model_ingredient = Ingredient('cnn_v2')


@model_ingredient.config
def model_config():
    # architecture
    input_shape = [6, 60]
    rnn_type = 'LSTM'  # LSTM/GRU
    rnn_layer = 2
    hid_size = 64
    dropout = 0
    # optimization
    optim_method = 'Adam'
    optim_args = {'lr': 1e-3}
    loss_fn = 'mse'
    eval_metric = 'corr'
    verbose = 500
    max_steps = 50
    early_stopping_rounds = 5
    out_chnls = [6,6,6],
    kernel = 4,
    output_path = "/home/amax/Documents/HM_CNN_RNN/out"

class InputConv(nn.Module):
    def __init__(self,
                 in_height,
                 in_width,
                 input_day,
                 out_chnls,
                 kernel):

        super().__init__()

        self.in_height = in_height
        self.in_width = in_width
        self.input_day = input_day
        self.out_chnls = out_chnls
        self.kernel = kernel

        self._build_model()

    def _build_model(self):

        self.cnn_2d= nn.Conv2d(1, self.out_chnls[0], kernel_size=[self.in_height,1], stride=1, padding=0) #[-1,1,6,16] -> [-1,6,1,16]
        input_chnl = self.out_chnls[0]
        self.cnn = nn.Sequential()
        for i, out_chnl in enumerate(self.out_chnls[1:]):  # [6,6,6]
            self.cnn.add_module('conv_%d'%(i+1),
                nn.Conv1d(input_chnl, out_chnl, kernel_size=self.kernel, stride=self.kernel, padding=0)) #[6,16] -> [6,4] -> [6,1])
            self.cnn.add_module("lrelu_%d"%(i+1), nn.LeakyReLU())
            input_chnl = out_chnl
        self.cnn.add_module('bn_%d'%(i+1), nn.BatchNorm1d(out_chnl))
        self.out_dim = out_chnl 

    def forward(self, inputs):
        inputs = inputs.view(-1, self.input_day, self.in_height, self.in_width)
        arr  = []
        for i in range(self.input_day):
            input = inputs[:,i,:,:] #[batch, input_day, input_size, input_length] -> [batch, input_size, input_length]
            input = input.unsqueeze(1) # [batch, input_size, input_length] -> [batch, 1, input_size, input_length]
            out = self.cnn_2d(input) # [batch, 1, input_size, input_length] -> [batch, out_chnls[0], 1, input_length]
            out = out.squeeze(2) # [batch, out_chnls[0], 1, input_length] -> [batch, out_chnls[0], input_length]
            out = self.cnn(out) #[batch, out_chnls[0], input_length] -> [batch, out_dim, 1]
            out = out.permute(0,2,1) #[batch, out_dim, 1] -> [batch, 1, out_dim]
            arr.append(out)
        day_reps = torch.cat(arr,dim=1) #arr: [batch, 1, out_dim] * input_day -> [batch, input_day, out_dim]
        return day_reps

class Model(nn.Module):
    @model_ingredient.capture
    def __init__(self,
                 input_shape,
                 rnn_type='LSTM',
                 rnn_layer=2,
                 hid_size=64,
                 dropout=0,
                 loss_fn ='mse',
                 optim_method='Adam',
                 optim_args={'lr': 1e-3},
                 eval_metric='corr',
                 out_chnls=[6,6,6],
                 kernel= 4):

        super().__init__()

        # Architecture
        self.hid_size = hid_size
        self.input_size = input_shape[0]
        self.input_length = input_shape[1]
        self.input_day = input_shape[2]
        self.dropout = dropout
        self.rnn_layer = rnn_layer
        self.rnn_type = rnn_type
        self.out_chnls = out_chnls
        self.kernel = kernel

        self._build_model()
        # Optimization
        self.optimizer = getattr(optim, optim_method)(self.parameters(),
                                                      **optim_args)
        self.loss_fn = get_loss_fn(loss_fn)
        self.metric_fn = get_metric_fn(eval_metric)

        if torch.cuda.is_available():
            self.cuda()

    def _build_model(self):

        try:
            klass = getattr(nn, self.rnn_type.upper())
        except:
            raise ValueError('unknown rnn_type `%s`' % self.rnn_type)

        self.input_conv = InputConv(in_height = self.input_size,
                                    in_width = self.input_length,
                                    input_day = self.input_day,
                                    out_chnls = self.out_chnls,
                                    kernel = self.kernel)

        self.net = nn.Sequential()
        self.net.add_module('fc_in',nn.Linear(in_features=self.input_size, out_features=self.hid_size))
        self.net.add_module('act',nn.Tanh())

        self.daily_rnn = klass(input_size=self.hid_size, 
                         hidden_size=self.hid_size,
                         num_layers=self.rnn_layer,
                         batch_first=True,
                         dropout=self.dropout) 
        self.fc_out = nn.Linear(in_features=self.hid_size, out_features=1)

    def forward(self, inputs):
        input_cnn = self.input_conv(inputs) # [batch, input_day, out_dim]
        fc_hid = self.net(input_cnn)
        daily_out, _ = self.daily_rnn(fc_hid)
        daily_out = self.fc_out(daily_out[:, -1, :]) # [batch, input_length, hid_size + free_hid] -> [batch, 1]
        return daily_out[..., 0]  # input_cnn: [batch, input_length, input_size]

    @model_ingredient.capture
    def fit(self,
            train_set,
            valid_set,
            run=None,
            max_steps=100,
            early_stopping_rounds=10,
            verbose=100):

        best_score = np.inf
        stop_steps = 0
        best_params = copy.deepcopy(self.state_dict())

        for step in range(max_steps):
            pprint('Step:', step)
            if stop_steps >= early_stopping_rounds:
                if verbose:
                    pprint('\tearly stop')
                break
            stop_steps += 1
            # training
            self.train()
            train_loss = AverageMeter()
            train_eval = AverageMeter()
            for i, (data, label) in enumerate(train_set):
                data = torch.tensor(data, dtype=torch.float)
                label = torch.tensor(label, dtype=torch.float)
                if torch.cuda.is_available():
                    data, label = data.cuda(), label.cuda()
                pred = self(data)
                loss = self.loss_fn(pred, label)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                train_loss.update(loss.item(), len(data))
                train_eval.update(self.metric_fn(pred, label).item())
                if verbose and i % verbose == 0:
                    pprint('iter %s: train_loss %.6f, train_eval %.6f' %
                           (i, train_loss.avg, train_eval.avg))
            # evaluation
            self.eval()
            valid_loss = AverageMeter()
            valid_eval = AverageMeter()
            for i, (data, label) in enumerate(valid_set):
                data = torch.tensor(data, dtype=torch.float)
                label = torch.tensor(label, dtype=torch.float)
                if torch.cuda.is_available():
                    data, label = data.cuda(), label.cuda()
                with torch.no_grad():
                    pred = self(data)
                loss = self.loss_fn(pred, label)
                valid_loss.update(loss.item(), len(data))
                valid_eval.update(self.metric_fn(pred, label).item())
            if run is not None:
                run.add_scalar('Train/Loss', train_loss.avg, step)
                run.add_scalar('Train/Eval', train_eval.avg, step)
                run.add_scalar('Valid/Loss', valid_loss.avg, step)
                run.add_scalar('Valid/Eval', valid_eval.avg, step)
            if verbose:
                pprint("current step: train_loss {:.6f}, valid_loss {:.6f}, "
                       "train_eval {:.6f}, valid_eval {:.6f}".format(
                           train_loss.avg, valid_loss.avg, train_eval.avg,
                           valid_eval.avg))
            if valid_eval.avg < best_score:
                if verbose:
                    pprint(
                        '\tvalid update from {:.6f} to {:.6f}, save checkpoint.'
                        .format(best_score, valid_eval.avg))
                best_score = valid_eval.avg
                stop_steps = 0
                best_params = copy.deepcopy(self.state_dict())
        # restore
        self.load_state_dict(best_params)

    def predict(self, test_set):
        self.eval()
        preds = []
        for i, (data, _) in enumerate(test_set):
            data = torch.tensor(data, dtype=torch.float)
            if torch.cuda.is_available():
                data = data.cuda()
            with torch.no_grad():
                preds.append(self(data).cpu().numpy())
        return np.concatenate(preds)

    def save(self, model_path):
        torch.save(self.state_dict(), model_path)

    def load(self, model_path, strict=True):
        self.load_state_dict(torch.load(model_path), strict=strict)
